var config =
{
//	server: 'http://localhost',
	server: 'http://54.202.22.196',
};