- Set AI server endpoint in 'config.js'.

- Add new tests to 'tests.js'.
	- Tests with 'reply:null' will act as comments and always succeed.

- Open 'index.html' in browser to open tester.
	- Click 'START TESTS' button to run the tests.
		- This button can be re-clicked to start tests from scratch.