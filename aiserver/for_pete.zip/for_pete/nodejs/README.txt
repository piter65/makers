you will also need socket.io

just run 
npm install socket.io
